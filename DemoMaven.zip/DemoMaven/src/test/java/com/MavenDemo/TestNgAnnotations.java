package com.MavenDemo;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.PageObjects.NextGenObjects;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.fedexUtilities.XLUtils;


public class TestNgAnnotations extends ClassBefore{
	
	String path = System.getProperty("user.dir") +"./src\\test\\java\\com\\TestData\\input.xlsx";
	
	
		@Test(dataProvider= "LoginData")
		public static void Test(String Firstname,String Lastname,String Gender,String Address,String Email,String Course,String Mobile,String Country,String Date) throws FileNotFoundException, IOException {
				System.out.println("First name"+Firstname  +" "+ "SecondName"+Lastname +" "+ "Address"+" "+Address+" "+"Email"+" "+Email+" "+"Gender"+Gender+" "+"Mobile"+Mobile+"Course"+Course+" "+"Country "+Country+" "+"Date"+Date);

				
				test= extent.createTest("Dimension Test" +Firstname);
				
				
				NextGenObjects ngo = new NextGenObjects(driver);
				ngo.EnterFirstName(Firstname);
				String temp= captureScreen(driver);
				test.pass("Clicked", MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
				
				ngo.EnterLastName(Lastname);
				
				ngo.EnterGender(Gender);
				
				ngo.EnterAddress(Address);
				
				ngo.EnterCountry(Country);
				
				ngo.EnterEmail(Email);
				NextGenObjects ngo1 = new NextGenObjects(driver);
				ngo1.EnterDate(Date);
				ngo1.EnterMobile(Mobile);
				ngo1.EnterCourse(Course);
				ngo1.Verify();
				ngo1.Verification();
				ngo1.EnterSubmit();	
				test.pass("Submit is clicked");
				 temp= captureScreen(driver);
				test.pass("Clicked", MediaEntityBuilder.createScreenCaptureFromPath(temp).build());

				if (ngo.VerifyResult()> 0) {

					System.out.println("pass");
					test.pass("Submit is clicked");
				} else {
					System.out.println("fail");
					test.fail("Failed");
				}
		
			}
			
	/*
		public Object[][] browserName() 
		{

			return new Object[][] { { "euyf","ee","ef","ee@gmail.com","Male","123","UFT","Angola","10/31/2000" }, { "second","secondlast","secondaddress","second@gmail.com","Female","321","TestNG","Chad","09/30/2000" }  };
		}
	*/	
		@DataProvider(name = "LoginData")
		String[][] getData() throws IOException
		{
			System.out.println(path);
			
			int rownum= XLUtils.getRowCount(path, "Sheet1");
			int colcont= XLUtils.getCellCount(path, "Sheet1", 0);
			System.out.println(rownum +" " + colcont);
			String logindata[][] = new String[rownum][colcont];
			for(int i=1;i<=rownum;i++)
			{
				
				for(int j=0;j<colcont;j++)
				{
					logindata[i-1][j]= XLUtils.getCellData(path,"Sheet1", i, j); //1 0
				}
				
			}	

			return logindata;
		}

	}	



